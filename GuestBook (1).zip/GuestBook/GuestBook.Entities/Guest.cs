﻿using System;

namespace GuestBook.Entities
{
    [Serializable]
    public class Guest
    {
        private int guestID;
        private string guestName;
        private string contactNumber;
        public int GuestID { get { return guestID; } set { guestID = value; } }
        public string GuestName { get { return guestName; } set { guestName = value; } }
        public string ContactNumber { get { return contactNumber; } set { contactNumber = value; } }
    }
}
